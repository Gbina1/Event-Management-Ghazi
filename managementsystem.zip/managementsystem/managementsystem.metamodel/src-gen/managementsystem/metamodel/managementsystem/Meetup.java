/**
 */
package managementsystem.metamodel.managementsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Meetup</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.Meetup#getGrouName <em>Grou Name</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Meetup#getRsvpLimit <em>Rsvp Limit</em>}</li>
 * </ul>
 *
 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getMeetup()
 * @model
 * @generated
 */
public interface Meetup extends Event {
	/**
	 * Returns the value of the '<em><b>Grou Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Grou Name</em>' attribute.
	 * @see #setGrouName(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getMeetup_GrouName()
	 * @model
	 * @generated
	 */
	String getGrouName();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Meetup#getGrouName <em>Grou Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Grou Name</em>' attribute.
	 * @see #getGrouName()
	 * @generated
	 */
	void setGrouName(String value);

	/**
	 * Returns the value of the '<em><b>Rsvp Limit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rsvp Limit</em>' attribute.
	 * @see #setRsvpLimit(int)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getMeetup_RsvpLimit()
	 * @model
	 * @generated
	 */
	int getRsvpLimit();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Meetup#getRsvpLimit <em>Rsvp Limit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rsvp Limit</em>' attribute.
	 * @see #getRsvpLimit()
	 * @generated
	 */
	void setRsvpLimit(int value);

} // Meetup
