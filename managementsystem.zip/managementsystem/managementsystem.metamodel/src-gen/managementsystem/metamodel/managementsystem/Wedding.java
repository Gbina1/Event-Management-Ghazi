/**
 */
package managementsystem.metamodel.managementsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Wedding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.Wedding#getBride <em>Bride</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Wedding#getGroom <em>Groom</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Wedding#getGuestList <em>Guest List</em>}</li>
 * </ul>
 *
 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getWedding()
 * @model
 * @generated
 */
public interface Wedding extends Event {
	/**
	 * Returns the value of the '<em><b>Bride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bride</em>' attribute.
	 * @see #setBride(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getWedding_Bride()
	 * @model
	 * @generated
	 */
	String getBride();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Wedding#getBride <em>Bride</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bride</em>' attribute.
	 * @see #getBride()
	 * @generated
	 */
	void setBride(String value);

	/**
	 * Returns the value of the '<em><b>Groom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Groom</em>' attribute.
	 * @see #setGroom(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getWedding_Groom()
	 * @model
	 * @generated
	 */
	String getGroom();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Wedding#getGroom <em>Groom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Groom</em>' attribute.
	 * @see #getGroom()
	 * @generated
	 */
	void setGroom(String value);

	/**
	 * Returns the value of the '<em><b>Guest List</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Guest List</em>' attribute.
	 * @see #setGuestList(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getWedding_GuestList()
	 * @model
	 * @generated
	 */
	String getGuestList();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Wedding#getGuestList <em>Guest List</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Guest List</em>' attribute.
	 * @see #getGuestList()
	 * @generated
	 */
	void setGuestList(String value);

} // Wedding
