/**
 */
package managementsystem.metamodel.managementsystem;

import java.util.Date;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getName <em>Name</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getStartDate <em>Start Date</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getEndDate <em>End Date</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getLocation <em>Location</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getEvent <em>Event</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getMeetup <em>Meetup</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getWedding <em>Wedding</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Event#getConference <em>Conference</em>}</li>
 * </ul>
 *
 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent()
 * @model abstract="true"
 * @generated
 */
public interface Event extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Start Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start Date</em>' attribute.
	 * @see #setStartDate(Date)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_StartDate()
	 * @model
	 * @generated
	 */
	Date getStartDate();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getStartDate <em>Start Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start Date</em>' attribute.
	 * @see #getStartDate()
	 * @generated
	 */
	void setStartDate(Date value);

	/**
	 * Returns the value of the '<em><b>End Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End Date</em>' attribute.
	 * @see #setEndDate(Date)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_EndDate()
	 * @model
	 * @generated
	 */
	Date getEndDate();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getEndDate <em>End Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End Date</em>' attribute.
	 * @see #getEndDate()
	 * @generated
	 */
	void setEndDate(Date value);

	/**
	 * Returns the value of the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' attribute.
	 * @see #setLocation(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_Location()
	 * @model
	 * @generated
	 */
	String getLocation();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getLocation <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' attribute.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(String value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' containment reference list.
	 * The list contents are of type {@link managementsystem.metamodel.managementsystem.EventManagement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' containment reference list.
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_Event()
	 * @model containment="true"
	 * @generated
	 */
	EList<EventManagement> getEvent();

	/**
	 * Returns the value of the '<em><b>Meetup</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Meetup</em>' reference.
	 * @see #setMeetup(Meetup)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_Meetup()
	 * @model
	 * @generated
	 */
	Meetup getMeetup();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getMeetup <em>Meetup</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Meetup</em>' reference.
	 * @see #getMeetup()
	 * @generated
	 */
	void setMeetup(Meetup value);

	/**
	 * Returns the value of the '<em><b>Wedding</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wedding</em>' reference.
	 * @see #setWedding(Wedding)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_Wedding()
	 * @model
	 * @generated
	 */
	Wedding getWedding();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getWedding <em>Wedding</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Wedding</em>' reference.
	 * @see #getWedding()
	 * @generated
	 */
	void setWedding(Wedding value);

	/**
	 * Returns the value of the '<em><b>Conference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Conference</em>' reference.
	 * @see #setConference(Conference)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEvent_Conference()
	 * @model
	 * @generated
	 */
	Conference getConference();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Event#getConference <em>Conference</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Conference</em>' reference.
	 * @see #getConference()
	 * @generated
	 */
	void setConference(Conference value);

} // Event
