/**
 */
package managementsystem.metamodel.managementsystem;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see managementsystem.metamodel.managementsystem.ManagementsystemFactory
 * @model kind="package"
 * @generated
 */
public interface ManagementsystemPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "managementsystem";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/managementsystem";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "managementsystem";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ManagementsystemPackage eINSTANCE = managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl
			.init();

	/**
	 * The meta object id for the '{@link managementsystem.metamodel.managementsystem.impl.ConferenceImpl <em>Conference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see managementsystem.metamodel.managementsystem.impl.ConferenceImpl
	 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getConference()
	 * @generated
	 */
	int CONFERENCE = 0;

	/**
	 * The meta object id for the '{@link managementsystem.metamodel.managementsystem.impl.WeddingImpl <em>Wedding</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see managementsystem.metamodel.managementsystem.impl.WeddingImpl
	 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getWedding()
	 * @generated
	 */
	int WEDDING = 1;

	/**
	 * The meta object id for the '{@link managementsystem.metamodel.managementsystem.impl.MeetupImpl <em>Meetup</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see managementsystem.metamodel.managementsystem.impl.MeetupImpl
	 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getMeetup()
	 * @generated
	 */
	int MEETUP = 2;

	/**
	 * The meta object id for the '{@link managementsystem.metamodel.managementsystem.impl.EventImpl <em>Event</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see managementsystem.metamodel.managementsystem.impl.EventImpl
	 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getEvent()
	 * @generated
	 */
	int EVENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Start Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__START_DATE = 1;

	/**
	 * The feature id for the '<em><b>End Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__END_DATE = 2;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__LOCATION = 3;

	/**
	 * The feature id for the '<em><b>Event</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__EVENT = 4;

	/**
	 * The feature id for the '<em><b>Meetup</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__MEETUP = 5;

	/**
	 * The feature id for the '<em><b>Wedding</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__WEDDING = 6;

	/**
	 * The feature id for the '<em><b>Conference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__CONFERENCE = 7;

	/**
	 * The number of structural features of the '<em>Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__NAME = EVENT__NAME;

	/**
	 * The feature id for the '<em><b>Start Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__START_DATE = EVENT__START_DATE;

	/**
	 * The feature id for the '<em><b>End Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__END_DATE = EVENT__END_DATE;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__LOCATION = EVENT__LOCATION;

	/**
	 * The feature id for the '<em><b>Event</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__EVENT = EVENT__EVENT;

	/**
	 * The feature id for the '<em><b>Meetup</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__MEETUP = EVENT__MEETUP;

	/**
	 * The feature id for the '<em><b>Wedding</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__WEDDING = EVENT__WEDDING;

	/**
	 * The feature id for the '<em><b>Conference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__CONFERENCE = EVENT__CONFERENCE;

	/**
	 * The feature id for the '<em><b>Num Talks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__NUM_TALKS = EVENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Speakers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE__SPEAKERS = EVENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Conference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE_FEATURE_COUNT = EVENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Conference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFERENCE_OPERATION_COUNT = EVENT_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__NAME = EVENT__NAME;

	/**
	 * The feature id for the '<em><b>Start Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__START_DATE = EVENT__START_DATE;

	/**
	 * The feature id for the '<em><b>End Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__END_DATE = EVENT__END_DATE;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__LOCATION = EVENT__LOCATION;

	/**
	 * The feature id for the '<em><b>Event</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__EVENT = EVENT__EVENT;

	/**
	 * The feature id for the '<em><b>Meetup</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__MEETUP = EVENT__MEETUP;

	/**
	 * The feature id for the '<em><b>Wedding</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__WEDDING = EVENT__WEDDING;

	/**
	 * The feature id for the '<em><b>Conference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__CONFERENCE = EVENT__CONFERENCE;

	/**
	 * The feature id for the '<em><b>Bride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__BRIDE = EVENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Groom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__GROOM = EVENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Guest List</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING__GUEST_LIST = EVENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Wedding</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING_FEATURE_COUNT = EVENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Wedding</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEDDING_OPERATION_COUNT = EVENT_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__NAME = EVENT__NAME;

	/**
	 * The feature id for the '<em><b>Start Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__START_DATE = EVENT__START_DATE;

	/**
	 * The feature id for the '<em><b>End Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__END_DATE = EVENT__END_DATE;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__LOCATION = EVENT__LOCATION;

	/**
	 * The feature id for the '<em><b>Event</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__EVENT = EVENT__EVENT;

	/**
	 * The feature id for the '<em><b>Meetup</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__MEETUP = EVENT__MEETUP;

	/**
	 * The feature id for the '<em><b>Wedding</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__WEDDING = EVENT__WEDDING;

	/**
	 * The feature id for the '<em><b>Conference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__CONFERENCE = EVENT__CONFERENCE;

	/**
	 * The feature id for the '<em><b>Grou Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__GROU_NAME = EVENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Rsvp Limit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP__RSVP_LIMIT = EVENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Meetup</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP_FEATURE_COUNT = EVENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Meetup</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEETUP_OPERATION_COUNT = EVENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link managementsystem.metamodel.managementsystem.impl.EventManagementImpl <em>Event Management</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see managementsystem.metamodel.managementsystem.impl.EventManagementImpl
	 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getEventManagement()
	 * @generated
	 */
	int EVENT_MANAGEMENT = 4;

	/**
	 * The number of structural features of the '<em>Event Management</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_MANAGEMENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Event Management</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_MANAGEMENT_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link managementsystem.metamodel.managementsystem.Conference <em>Conference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conference</em>'.
	 * @see managementsystem.metamodel.managementsystem.Conference
	 * @generated
	 */
	EClass getConference();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Conference#getNumTalks <em>Num Talks</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Num Talks</em>'.
	 * @see managementsystem.metamodel.managementsystem.Conference#getNumTalks()
	 * @see #getConference()
	 * @generated
	 */
	EAttribute getConference_NumTalks();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Conference#getSpeakers <em>Speakers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Speakers</em>'.
	 * @see managementsystem.metamodel.managementsystem.Conference#getSpeakers()
	 * @see #getConference()
	 * @generated
	 */
	EAttribute getConference_Speakers();

	/**
	 * Returns the meta object for class '{@link managementsystem.metamodel.managementsystem.Wedding <em>Wedding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Wedding</em>'.
	 * @see managementsystem.metamodel.managementsystem.Wedding
	 * @generated
	 */
	EClass getWedding();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Wedding#getBride <em>Bride</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bride</em>'.
	 * @see managementsystem.metamodel.managementsystem.Wedding#getBride()
	 * @see #getWedding()
	 * @generated
	 */
	EAttribute getWedding_Bride();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Wedding#getGroom <em>Groom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Groom</em>'.
	 * @see managementsystem.metamodel.managementsystem.Wedding#getGroom()
	 * @see #getWedding()
	 * @generated
	 */
	EAttribute getWedding_Groom();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Wedding#getGuestList <em>Guest List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Guest List</em>'.
	 * @see managementsystem.metamodel.managementsystem.Wedding#getGuestList()
	 * @see #getWedding()
	 * @generated
	 */
	EAttribute getWedding_GuestList();

	/**
	 * Returns the meta object for class '{@link managementsystem.metamodel.managementsystem.Meetup <em>Meetup</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Meetup</em>'.
	 * @see managementsystem.metamodel.managementsystem.Meetup
	 * @generated
	 */
	EClass getMeetup();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Meetup#getGrouName <em>Grou Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Grou Name</em>'.
	 * @see managementsystem.metamodel.managementsystem.Meetup#getGrouName()
	 * @see #getMeetup()
	 * @generated
	 */
	EAttribute getMeetup_GrouName();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Meetup#getRsvpLimit <em>Rsvp Limit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rsvp Limit</em>'.
	 * @see managementsystem.metamodel.managementsystem.Meetup#getRsvpLimit()
	 * @see #getMeetup()
	 * @generated
	 */
	EAttribute getMeetup_RsvpLimit();

	/**
	 * Returns the meta object for class '{@link managementsystem.metamodel.managementsystem.Event <em>Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Event</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event
	 * @generated
	 */
	EClass getEvent();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Event#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getName()
	 * @see #getEvent()
	 * @generated
	 */
	EAttribute getEvent_Name();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Event#getStartDate <em>Start Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start Date</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getStartDate()
	 * @see #getEvent()
	 * @generated
	 */
	EAttribute getEvent_StartDate();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Event#getEndDate <em>End Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End Date</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getEndDate()
	 * @see #getEvent()
	 * @generated
	 */
	EAttribute getEvent_EndDate();

	/**
	 * Returns the meta object for the attribute '{@link managementsystem.metamodel.managementsystem.Event#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getLocation()
	 * @see #getEvent()
	 * @generated
	 */
	EAttribute getEvent_Location();

	/**
	 * Returns the meta object for the containment reference list '{@link managementsystem.metamodel.managementsystem.Event#getEvent <em>Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Event</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getEvent()
	 * @see #getEvent()
	 * @generated
	 */
	EReference getEvent_Event();

	/**
	 * Returns the meta object for the reference '{@link managementsystem.metamodel.managementsystem.Event#getMeetup <em>Meetup</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Meetup</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getMeetup()
	 * @see #getEvent()
	 * @generated
	 */
	EReference getEvent_Meetup();

	/**
	 * Returns the meta object for the reference '{@link managementsystem.metamodel.managementsystem.Event#getWedding <em>Wedding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Wedding</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getWedding()
	 * @see #getEvent()
	 * @generated
	 */
	EReference getEvent_Wedding();

	/**
	 * Returns the meta object for the reference '{@link managementsystem.metamodel.managementsystem.Event#getConference <em>Conference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Conference</em>'.
	 * @see managementsystem.metamodel.managementsystem.Event#getConference()
	 * @see #getEvent()
	 * @generated
	 */
	EReference getEvent_Conference();

	/**
	 * Returns the meta object for class '{@link managementsystem.metamodel.managementsystem.EventManagement <em>Event Management</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Event Management</em>'.
	 * @see managementsystem.metamodel.managementsystem.EventManagement
	 * @generated
	 */
	EClass getEventManagement();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ManagementsystemFactory getManagementsystemFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link managementsystem.metamodel.managementsystem.impl.ConferenceImpl <em>Conference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see managementsystem.metamodel.managementsystem.impl.ConferenceImpl
		 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getConference()
		 * @generated
		 */
		EClass CONFERENCE = eINSTANCE.getConference();

		/**
		 * The meta object literal for the '<em><b>Num Talks</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONFERENCE__NUM_TALKS = eINSTANCE.getConference_NumTalks();

		/**
		 * The meta object literal for the '<em><b>Speakers</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONFERENCE__SPEAKERS = eINSTANCE.getConference_Speakers();

		/**
		 * The meta object literal for the '{@link managementsystem.metamodel.managementsystem.impl.WeddingImpl <em>Wedding</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see managementsystem.metamodel.managementsystem.impl.WeddingImpl
		 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getWedding()
		 * @generated
		 */
		EClass WEDDING = eINSTANCE.getWedding();

		/**
		 * The meta object literal for the '<em><b>Bride</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEDDING__BRIDE = eINSTANCE.getWedding_Bride();

		/**
		 * The meta object literal for the '<em><b>Groom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEDDING__GROOM = eINSTANCE.getWedding_Groom();

		/**
		 * The meta object literal for the '<em><b>Guest List</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEDDING__GUEST_LIST = eINSTANCE.getWedding_GuestList();

		/**
		 * The meta object literal for the '{@link managementsystem.metamodel.managementsystem.impl.MeetupImpl <em>Meetup</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see managementsystem.metamodel.managementsystem.impl.MeetupImpl
		 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getMeetup()
		 * @generated
		 */
		EClass MEETUP = eINSTANCE.getMeetup();

		/**
		 * The meta object literal for the '<em><b>Grou Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEETUP__GROU_NAME = eINSTANCE.getMeetup_GrouName();

		/**
		 * The meta object literal for the '<em><b>Rsvp Limit</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEETUP__RSVP_LIMIT = eINSTANCE.getMeetup_RsvpLimit();

		/**
		 * The meta object literal for the '{@link managementsystem.metamodel.managementsystem.impl.EventImpl <em>Event</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see managementsystem.metamodel.managementsystem.impl.EventImpl
		 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getEvent()
		 * @generated
		 */
		EClass EVENT = eINSTANCE.getEvent();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EVENT__NAME = eINSTANCE.getEvent_Name();

		/**
		 * The meta object literal for the '<em><b>Start Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EVENT__START_DATE = eINSTANCE.getEvent_StartDate();

		/**
		 * The meta object literal for the '<em><b>End Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EVENT__END_DATE = eINSTANCE.getEvent_EndDate();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EVENT__LOCATION = eINSTANCE.getEvent_Location();

		/**
		 * The meta object literal for the '<em><b>Event</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT__EVENT = eINSTANCE.getEvent_Event();

		/**
		 * The meta object literal for the '<em><b>Meetup</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT__MEETUP = eINSTANCE.getEvent_Meetup();

		/**
		 * The meta object literal for the '<em><b>Wedding</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT__WEDDING = eINSTANCE.getEvent_Wedding();

		/**
		 * The meta object literal for the '<em><b>Conference</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EVENT__CONFERENCE = eINSTANCE.getEvent_Conference();

		/**
		 * The meta object literal for the '{@link managementsystem.metamodel.managementsystem.impl.EventManagementImpl <em>Event Management</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see managementsystem.metamodel.managementsystem.impl.EventManagementImpl
		 * @see managementsystem.metamodel.managementsystem.impl.ManagementsystemPackageImpl#getEventManagement()
		 * @generated
		 */
		EClass EVENT_MANAGEMENT = eINSTANCE.getEventManagement();

	}

} //ManagementsystemPackage
