/**
 */
package managementsystem.metamodel.managementsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conference</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.Conference#getNumTalks <em>Num Talks</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.Conference#getSpeakers <em>Speakers</em>}</li>
 * </ul>
 *
 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getConference()
 * @model
 * @generated
 */
public interface Conference extends Event {
	/**
	 * Returns the value of the '<em><b>Num Talks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Num Talks</em>' attribute.
	 * @see #setNumTalks(int)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getConference_NumTalks()
	 * @model
	 * @generated
	 */
	int getNumTalks();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Conference#getNumTalks <em>Num Talks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Num Talks</em>' attribute.
	 * @see #getNumTalks()
	 * @generated
	 */
	void setNumTalks(int value);

	/**
	 * Returns the value of the '<em><b>Speakers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Speakers</em>' attribute.
	 * @see #setSpeakers(String)
	 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getConference_Speakers()
	 * @model
	 * @generated
	 */
	String getSpeakers();

	/**
	 * Sets the value of the '{@link managementsystem.metamodel.managementsystem.Conference#getSpeakers <em>Speakers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Speakers</em>' attribute.
	 * @see #getSpeakers()
	 * @generated
	 */
	void setSpeakers(String value);

} // Conference
