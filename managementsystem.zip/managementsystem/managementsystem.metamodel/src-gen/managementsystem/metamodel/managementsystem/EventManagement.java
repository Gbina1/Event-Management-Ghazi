/**
 */
package managementsystem.metamodel.managementsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Management</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage#getEventManagement()
 * @model
 * @generated
 */
public interface EventManagement extends EObject {

} // EventManagement
