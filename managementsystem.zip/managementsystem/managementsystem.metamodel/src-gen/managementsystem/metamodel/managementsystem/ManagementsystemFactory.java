/**
 */
package managementsystem.metamodel.managementsystem;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see managementsystem.metamodel.managementsystem.ManagementsystemPackage
 * @generated
 */
public interface ManagementsystemFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ManagementsystemFactory eINSTANCE = managementsystem.metamodel.managementsystem.impl.ManagementsystemFactoryImpl
			.init();

	/**
	 * Returns a new object of class '<em>Conference</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Conference</em>'.
	 * @generated
	 */
	Conference createConference();

	/**
	 * Returns a new object of class '<em>Wedding</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Wedding</em>'.
	 * @generated
	 */
	Wedding createWedding();

	/**
	 * Returns a new object of class '<em>Meetup</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Meetup</em>'.
	 * @generated
	 */
	Meetup createMeetup();

	/**
	 * Returns a new object of class '<em>Event Management</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Management</em>'.
	 * @generated
	 */
	EventManagement createEventManagement();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ManagementsystemPackage getManagementsystemPackage();

} //ManagementsystemFactory
