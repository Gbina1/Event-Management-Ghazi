/**
 */
package managementsystem.metamodel.managementsystem.impl;

import managementsystem.metamodel.managementsystem.ManagementsystemPackage;
import managementsystem.metamodel.managementsystem.Wedding;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Wedding</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.WeddingImpl#getBride <em>Bride</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.WeddingImpl#getGroom <em>Groom</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.WeddingImpl#getGuestList <em>Guest List</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WeddingImpl extends EventImpl implements Wedding {
	/**
	 * The default value of the '{@link #getBride() <em>Bride</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBride()
	 * @generated
	 * @ordered
	 */
	protected static final String BRIDE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBride() <em>Bride</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBride()
	 * @generated
	 * @ordered
	 */
	protected String bride = BRIDE_EDEFAULT;

	/**
	 * The default value of the '{@link #getGroom() <em>Groom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGroom()
	 * @generated
	 * @ordered
	 */
	protected static final String GROOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGroom() <em>Groom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGroom()
	 * @generated
	 * @ordered
	 */
	protected String groom = GROOM_EDEFAULT;

	/**
	 * The default value of the '{@link #getGuestList() <em>Guest List</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGuestList()
	 * @generated
	 * @ordered
	 */
	protected static final String GUEST_LIST_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGuestList() <em>Guest List</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGuestList()
	 * @generated
	 * @ordered
	 */
	protected String guestList = GUEST_LIST_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WeddingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ManagementsystemPackage.Literals.WEDDING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBride() {
		return bride;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBride(String newBride) {
		String oldBride = bride;
		bride = newBride;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.WEDDING__BRIDE, oldBride,
					bride));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGroom() {
		return groom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGroom(String newGroom) {
		String oldGroom = groom;
		groom = newGroom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.WEDDING__GROOM, oldGroom,
					groom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGuestList() {
		return guestList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGuestList(String newGuestList) {
		String oldGuestList = guestList;
		guestList = newGuestList;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.WEDDING__GUEST_LIST,
					oldGuestList, guestList));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ManagementsystemPackage.WEDDING__BRIDE:
			return getBride();
		case ManagementsystemPackage.WEDDING__GROOM:
			return getGroom();
		case ManagementsystemPackage.WEDDING__GUEST_LIST:
			return getGuestList();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ManagementsystemPackage.WEDDING__BRIDE:
			setBride((String) newValue);
			return;
		case ManagementsystemPackage.WEDDING__GROOM:
			setGroom((String) newValue);
			return;
		case ManagementsystemPackage.WEDDING__GUEST_LIST:
			setGuestList((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.WEDDING__BRIDE:
			setBride(BRIDE_EDEFAULT);
			return;
		case ManagementsystemPackage.WEDDING__GROOM:
			setGroom(GROOM_EDEFAULT);
			return;
		case ManagementsystemPackage.WEDDING__GUEST_LIST:
			setGuestList(GUEST_LIST_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.WEDDING__BRIDE:
			return BRIDE_EDEFAULT == null ? bride != null : !BRIDE_EDEFAULT.equals(bride);
		case ManagementsystemPackage.WEDDING__GROOM:
			return GROOM_EDEFAULT == null ? groom != null : !GROOM_EDEFAULT.equals(groom);
		case ManagementsystemPackage.WEDDING__GUEST_LIST:
			return GUEST_LIST_EDEFAULT == null ? guestList != null : !GUEST_LIST_EDEFAULT.equals(guestList);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (bride: ");
		result.append(bride);
		result.append(", groom: ");
		result.append(groom);
		result.append(", guestList: ");
		result.append(guestList);
		result.append(')');
		return result.toString();
	}

} //WeddingImpl
