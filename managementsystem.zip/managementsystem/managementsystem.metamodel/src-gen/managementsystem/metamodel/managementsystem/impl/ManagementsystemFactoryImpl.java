/**
 */
package managementsystem.metamodel.managementsystem.impl;

import managementsystem.metamodel.managementsystem.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ManagementsystemFactoryImpl extends EFactoryImpl implements ManagementsystemFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ManagementsystemFactory init() {
		try {
			ManagementsystemFactory theManagementsystemFactory = (ManagementsystemFactory) EPackage.Registry.INSTANCE
					.getEFactory(ManagementsystemPackage.eNS_URI);
			if (theManagementsystemFactory != null) {
				return theManagementsystemFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ManagementsystemFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ManagementsystemFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ManagementsystemPackage.CONFERENCE:
			return createConference();
		case ManagementsystemPackage.WEDDING:
			return createWedding();
		case ManagementsystemPackage.MEETUP:
			return createMeetup();
		case ManagementsystemPackage.EVENT_MANAGEMENT:
			return createEventManagement();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conference createConference() {
		ConferenceImpl conference = new ConferenceImpl();
		return conference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wedding createWedding() {
		WeddingImpl wedding = new WeddingImpl();
		return wedding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Meetup createMeetup() {
		MeetupImpl meetup = new MeetupImpl();
		return meetup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventManagement createEventManagement() {
		EventManagementImpl eventManagement = new EventManagementImpl();
		return eventManagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ManagementsystemPackage getManagementsystemPackage() {
		return (ManagementsystemPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ManagementsystemPackage getPackage() {
		return ManagementsystemPackage.eINSTANCE;
	}

} //ManagementsystemFactoryImpl
