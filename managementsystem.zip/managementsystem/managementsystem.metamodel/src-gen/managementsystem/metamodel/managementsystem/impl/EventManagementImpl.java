/**
 */
package managementsystem.metamodel.managementsystem.impl;

import managementsystem.metamodel.managementsystem.EventManagement;
import managementsystem.metamodel.managementsystem.ManagementsystemPackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Management</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EventManagementImpl extends MinimalEObjectImpl.Container implements EventManagement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventManagementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ManagementsystemPackage.Literals.EVENT_MANAGEMENT;
	}

} //EventManagementImpl
