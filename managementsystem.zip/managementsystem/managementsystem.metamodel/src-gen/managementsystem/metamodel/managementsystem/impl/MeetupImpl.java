/**
 */
package managementsystem.metamodel.managementsystem.impl;

import managementsystem.metamodel.managementsystem.ManagementsystemPackage;
import managementsystem.metamodel.managementsystem.Meetup;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Meetup</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.MeetupImpl#getGrouName <em>Grou Name</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.MeetupImpl#getRsvpLimit <em>Rsvp Limit</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MeetupImpl extends EventImpl implements Meetup {
	/**
	 * The default value of the '{@link #getGrouName() <em>Grou Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGrouName()
	 * @generated
	 * @ordered
	 */
	protected static final String GROU_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGrouName() <em>Grou Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGrouName()
	 * @generated
	 * @ordered
	 */
	protected String grouName = GROU_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getRsvpLimit() <em>Rsvp Limit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRsvpLimit()
	 * @generated
	 * @ordered
	 */
	protected static final int RSVP_LIMIT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getRsvpLimit() <em>Rsvp Limit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRsvpLimit()
	 * @generated
	 * @ordered
	 */
	protected int rsvpLimit = RSVP_LIMIT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MeetupImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ManagementsystemPackage.Literals.MEETUP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGrouName() {
		return grouName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGrouName(String newGrouName) {
		String oldGrouName = grouName;
		grouName = newGrouName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.MEETUP__GROU_NAME,
					oldGrouName, grouName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getRsvpLimit() {
		return rsvpLimit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRsvpLimit(int newRsvpLimit) {
		int oldRsvpLimit = rsvpLimit;
		rsvpLimit = newRsvpLimit;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.MEETUP__RSVP_LIMIT,
					oldRsvpLimit, rsvpLimit));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ManagementsystemPackage.MEETUP__GROU_NAME:
			return getGrouName();
		case ManagementsystemPackage.MEETUP__RSVP_LIMIT:
			return getRsvpLimit();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ManagementsystemPackage.MEETUP__GROU_NAME:
			setGrouName((String) newValue);
			return;
		case ManagementsystemPackage.MEETUP__RSVP_LIMIT:
			setRsvpLimit((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.MEETUP__GROU_NAME:
			setGrouName(GROU_NAME_EDEFAULT);
			return;
		case ManagementsystemPackage.MEETUP__RSVP_LIMIT:
			setRsvpLimit(RSVP_LIMIT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.MEETUP__GROU_NAME:
			return GROU_NAME_EDEFAULT == null ? grouName != null : !GROU_NAME_EDEFAULT.equals(grouName);
		case ManagementsystemPackage.MEETUP__RSVP_LIMIT:
			return rsvpLimit != RSVP_LIMIT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (grouName: ");
		result.append(grouName);
		result.append(", rsvpLimit: ");
		result.append(rsvpLimit);
		result.append(')');
		return result.toString();
	}

} //MeetupImpl
