/**
 */
package managementsystem.metamodel.managementsystem.impl;

import managementsystem.metamodel.managementsystem.Conference;
import managementsystem.metamodel.managementsystem.ManagementsystemPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Conference</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.ConferenceImpl#getNumTalks <em>Num Talks</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.ConferenceImpl#getSpeakers <em>Speakers</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConferenceImpl extends EventImpl implements Conference {
	/**
	 * The default value of the '{@link #getNumTalks() <em>Num Talks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumTalks()
	 * @generated
	 * @ordered
	 */
	protected static final int NUM_TALKS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNumTalks() <em>Num Talks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumTalks()
	 * @generated
	 * @ordered
	 */
	protected int numTalks = NUM_TALKS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSpeakers() <em>Speakers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeakers()
	 * @generated
	 * @ordered
	 */
	protected static final String SPEAKERS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSpeakers() <em>Speakers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeakers()
	 * @generated
	 * @ordered
	 */
	protected String speakers = SPEAKERS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConferenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ManagementsystemPackage.Literals.CONFERENCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNumTalks() {
		return numTalks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNumTalks(int newNumTalks) {
		int oldNumTalks = numTalks;
		numTalks = newNumTalks;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.CONFERENCE__NUM_TALKS,
					oldNumTalks, numTalks));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSpeakers() {
		return speakers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpeakers(String newSpeakers) {
		String oldSpeakers = speakers;
		speakers = newSpeakers;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.CONFERENCE__SPEAKERS,
					oldSpeakers, speakers));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ManagementsystemPackage.CONFERENCE__NUM_TALKS:
			return getNumTalks();
		case ManagementsystemPackage.CONFERENCE__SPEAKERS:
			return getSpeakers();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ManagementsystemPackage.CONFERENCE__NUM_TALKS:
			setNumTalks((Integer) newValue);
			return;
		case ManagementsystemPackage.CONFERENCE__SPEAKERS:
			setSpeakers((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.CONFERENCE__NUM_TALKS:
			setNumTalks(NUM_TALKS_EDEFAULT);
			return;
		case ManagementsystemPackage.CONFERENCE__SPEAKERS:
			setSpeakers(SPEAKERS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.CONFERENCE__NUM_TALKS:
			return numTalks != NUM_TALKS_EDEFAULT;
		case ManagementsystemPackage.CONFERENCE__SPEAKERS:
			return SPEAKERS_EDEFAULT == null ? speakers != null : !SPEAKERS_EDEFAULT.equals(speakers);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (numTalks: ");
		result.append(numTalks);
		result.append(", speakers: ");
		result.append(speakers);
		result.append(')');
		return result.toString();
	}

} //ConferenceImpl
