/**
 */
package managementsystem.metamodel.managementsystem.impl;

import java.util.Collection;
import java.util.Date;

import managementsystem.metamodel.managementsystem.Conference;
import managementsystem.metamodel.managementsystem.Event;
import managementsystem.metamodel.managementsystem.EventManagement;
import managementsystem.metamodel.managementsystem.ManagementsystemPackage;

import managementsystem.metamodel.managementsystem.Meetup;
import managementsystem.metamodel.managementsystem.Wedding;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getName <em>Name</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getStartDate <em>Start Date</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getEndDate <em>End Date</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getEvent <em>Event</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getMeetup <em>Meetup</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getWedding <em>Wedding</em>}</li>
 *   <li>{@link managementsystem.metamodel.managementsystem.impl.EventImpl#getConference <em>Conference</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class EventImpl extends MinimalEObjectImpl.Container implements Event {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getStartDate() <em>Start Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date START_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStartDate() <em>Start Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartDate()
	 * @generated
	 * @ordered
	 */
	protected Date startDate = START_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getEndDate() <em>End Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date END_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEndDate() <em>End Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndDate()
	 * @generated
	 * @ordered
	 */
	protected Date endDate = END_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected static final String LOCATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected String location = LOCATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getEvent() <em>Event</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEvent()
	 * @generated
	 * @ordered
	 */
	protected EList<EventManagement> event;

	/**
	 * The cached value of the '{@link #getMeetup() <em>Meetup</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMeetup()
	 * @generated
	 * @ordered
	 */
	protected Meetup meetup;

	/**
	 * The cached value of the '{@link #getWedding() <em>Wedding</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWedding()
	 * @generated
	 * @ordered
	 */
	protected Wedding wedding;

	/**
	 * The cached value of the '{@link #getConference() <em>Conference</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConference()
	 * @generated
	 * @ordered
	 */
	protected Conference conference;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ManagementsystemPackage.Literals.EVENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStartDate(Date newStartDate) {
		Date oldStartDate = startDate;
		startDate = newStartDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__START_DATE,
					oldStartDate, startDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEndDate(Date newEndDate) {
		Date oldEndDate = endDate;
		endDate = newEndDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__END_DATE, oldEndDate,
					endDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(String newLocation) {
		String oldLocation = location;
		location = newLocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__LOCATION, oldLocation,
					location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EventManagement> getEvent() {
		if (event == null) {
			event = new EObjectContainmentEList<EventManagement>(EventManagement.class, this,
					ManagementsystemPackage.EVENT__EVENT);
		}
		return event;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Meetup getMeetup() {
		if (meetup != null && meetup.eIsProxy()) {
			InternalEObject oldMeetup = (InternalEObject) meetup;
			meetup = (Meetup) eResolveProxy(oldMeetup);
			if (meetup != oldMeetup) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ManagementsystemPackage.EVENT__MEETUP,
							oldMeetup, meetup));
			}
		}
		return meetup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Meetup basicGetMeetup() {
		return meetup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMeetup(Meetup newMeetup) {
		Meetup oldMeetup = meetup;
		meetup = newMeetup;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__MEETUP, oldMeetup,
					meetup));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wedding getWedding() {
		if (wedding != null && wedding.eIsProxy()) {
			InternalEObject oldWedding = (InternalEObject) wedding;
			wedding = (Wedding) eResolveProxy(oldWedding);
			if (wedding != oldWedding) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ManagementsystemPackage.EVENT__WEDDING,
							oldWedding, wedding));
			}
		}
		return wedding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wedding basicGetWedding() {
		return wedding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWedding(Wedding newWedding) {
		Wedding oldWedding = wedding;
		wedding = newWedding;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__WEDDING, oldWedding,
					wedding));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conference getConference() {
		if (conference != null && conference.eIsProxy()) {
			InternalEObject oldConference = (InternalEObject) conference;
			conference = (Conference) eResolveProxy(oldConference);
			if (conference != oldConference) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ManagementsystemPackage.EVENT__CONFERENCE,
							oldConference, conference));
			}
		}
		return conference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conference basicGetConference() {
		return conference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConference(Conference newConference) {
		Conference oldConference = conference;
		conference = newConference;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ManagementsystemPackage.EVENT__CONFERENCE,
					oldConference, conference));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ManagementsystemPackage.EVENT__EVENT:
			return ((InternalEList<?>) getEvent()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ManagementsystemPackage.EVENT__NAME:
			return getName();
		case ManagementsystemPackage.EVENT__START_DATE:
			return getStartDate();
		case ManagementsystemPackage.EVENT__END_DATE:
			return getEndDate();
		case ManagementsystemPackage.EVENT__LOCATION:
			return getLocation();
		case ManagementsystemPackage.EVENT__EVENT:
			return getEvent();
		case ManagementsystemPackage.EVENT__MEETUP:
			if (resolve)
				return getMeetup();
			return basicGetMeetup();
		case ManagementsystemPackage.EVENT__WEDDING:
			if (resolve)
				return getWedding();
			return basicGetWedding();
		case ManagementsystemPackage.EVENT__CONFERENCE:
			if (resolve)
				return getConference();
			return basicGetConference();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ManagementsystemPackage.EVENT__NAME:
			setName((String) newValue);
			return;
		case ManagementsystemPackage.EVENT__START_DATE:
			setStartDate((Date) newValue);
			return;
		case ManagementsystemPackage.EVENT__END_DATE:
			setEndDate((Date) newValue);
			return;
		case ManagementsystemPackage.EVENT__LOCATION:
			setLocation((String) newValue);
			return;
		case ManagementsystemPackage.EVENT__EVENT:
			getEvent().clear();
			getEvent().addAll((Collection<? extends EventManagement>) newValue);
			return;
		case ManagementsystemPackage.EVENT__MEETUP:
			setMeetup((Meetup) newValue);
			return;
		case ManagementsystemPackage.EVENT__WEDDING:
			setWedding((Wedding) newValue);
			return;
		case ManagementsystemPackage.EVENT__CONFERENCE:
			setConference((Conference) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.EVENT__NAME:
			setName(NAME_EDEFAULT);
			return;
		case ManagementsystemPackage.EVENT__START_DATE:
			setStartDate(START_DATE_EDEFAULT);
			return;
		case ManagementsystemPackage.EVENT__END_DATE:
			setEndDate(END_DATE_EDEFAULT);
			return;
		case ManagementsystemPackage.EVENT__LOCATION:
			setLocation(LOCATION_EDEFAULT);
			return;
		case ManagementsystemPackage.EVENT__EVENT:
			getEvent().clear();
			return;
		case ManagementsystemPackage.EVENT__MEETUP:
			setMeetup((Meetup) null);
			return;
		case ManagementsystemPackage.EVENT__WEDDING:
			setWedding((Wedding) null);
			return;
		case ManagementsystemPackage.EVENT__CONFERENCE:
			setConference((Conference) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ManagementsystemPackage.EVENT__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case ManagementsystemPackage.EVENT__START_DATE:
			return START_DATE_EDEFAULT == null ? startDate != null : !START_DATE_EDEFAULT.equals(startDate);
		case ManagementsystemPackage.EVENT__END_DATE:
			return END_DATE_EDEFAULT == null ? endDate != null : !END_DATE_EDEFAULT.equals(endDate);
		case ManagementsystemPackage.EVENT__LOCATION:
			return LOCATION_EDEFAULT == null ? location != null : !LOCATION_EDEFAULT.equals(location);
		case ManagementsystemPackage.EVENT__EVENT:
			return event != null && !event.isEmpty();
		case ManagementsystemPackage.EVENT__MEETUP:
			return meetup != null;
		case ManagementsystemPackage.EVENT__WEDDING:
			return wedding != null;
		case ManagementsystemPackage.EVENT__CONFERENCE:
			return conference != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", startDate: ");
		result.append(startDate);
		result.append(", endDate: ");
		result.append(endDate);
		result.append(", location: ");
		result.append(location);
		result.append(')');
		return result.toString();
	}

} //EventImpl
